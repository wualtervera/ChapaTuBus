<?php 
	define('BASE_URL', 'http://127.0.0.1/maps');
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASS', '');
	define('DB_NAME', 'inso');
	define('DB_CHARSET', 'utf8');
?>